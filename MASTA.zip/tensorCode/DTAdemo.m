function [T, Cnew] = DTA(tn, R,  C, alpha)

if nargin<2
    error('not enough inputs');
end
N = 2;
if nargin<3 % no pior co-variance matrices, initialize to be 0
    C = {};
    dv = [tn tn];
    for n = 1:N
        C{end+1} = sparse(dv(n),dv(n));
    end
end
if nargin<4
    alpha = 1; %no forgetting factor
end
    
%% Update covariance matrices C and compute U
U = {};
for n = 1:N
    XM = rand(tn,tn);
    Cnew{n} = alpha*C{n} + XM*XM';
    opts.disp = 0;
    opts.issym = 1;
    [U{n}, D] = eigs(Cnew{n},R(n),'LM',opts);    
end

%% compute core
core = ttm(tensor(XM), U, 't');
T = ttensor(core, U);
