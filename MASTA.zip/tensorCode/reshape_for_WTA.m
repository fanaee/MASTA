function [X,new_index]=reshape_for_WTA(X,timemode)

if timemode==1
	new_index=(1:length(size(X)));;
	return;
end


SX=size(X);
SX1=SX;
SX(timemode)=[];
Xadd='X=reshape(X,size(X,timemode),';

p1=(1:timemode-1);
p2=(timemode+1:length(SX1));

new_index=[timemode,p1,p2];
for i=1:length(SX)
        Xadd = [Xadd,int2str(SX(i))];
        if i<length(SX)
            Xadd=[Xadd,','];
        else
            Xadd=[Xadd,');'];
        end   
end    

eval(Xadd);
