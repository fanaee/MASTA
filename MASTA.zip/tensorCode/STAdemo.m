function [Tnew, S] = STA(tn, R, T, S, alpha, samplingPercent)

if nargin<2
    error('not enough inputs');
end
N = 2;
if nargin<3 
    % no pior co-variance matrices, initialize to be truncated identity
    dv = [tn tn];
    for i=1:N
        U{i} = eye(dv(i),R(i));
    end
else
    %check if the input R match the size of T.U
    for i=1:N
       if size(T.U{i},2)~=R(i)
           error('Rank mismatch on %d mode\n',i);
       end
    end
    U = T.U;
end
if nargin<4
    S = {};
    for i = 1:N
        S{i} = 1e-10*ones(R(i)); %no prior on energy; 
    end
end
if nargin<5
    alpha = 1; %no forgetting factor
end
if nargin<6
    samplingPercent = 0.1; %default sampling percentage is 10%
end
%% Doing STA for each mode
for n = 1:N
% matricize Xnew
	XM=rand(tn,tn);
% Sampling the vectors
    ids = sampleCol(XM, samplingPercent);
% Update the projection matrices in the old tucker tensor
    Schange = zeros(size(S{n}));
    for i = ids
        x = XM(:,i);
        [U{n},S{n}] = STA_vec(x, S{n}, U{n}, alpha);        
    end
    for i = 1:size(U{n},2) %renormalization (precaution, maybe not necessary)
        U{n}(:,i) = U{n}(:,i)/norm(U{n}(:,i));
    end
end
%% compute core
core = ttm(tensor(XM), U, 't');
Tnew = ttensor(core, U);
return;
%% sampling function
function ids = sampleCol(X, p)
if nargin<2
    p = 1;
end
Xs = full(sum(abs(X),1));
[v, ids] = sort(Xs,'descend');
id2 = find(v>0);
id2 = id2(end);
ids = ids(1:max(floor(p*id2),1));
return;
%% STA update on a vector
function [U, dnew] = STA_vec(x, d, U, alpha)
%streamingTPCA: update U matrix based on vector x
    dnew = d;
    for i = 1:size(U,2) %update one column of U at a time
        [U(:,i),dnew(i), x] = updateW(x, U(:,i), d(i), alpha);
    end
    U = grams(U); % re-orthogonalization
return;
