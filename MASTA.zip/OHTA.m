function [res result tHist tSlice]=OHTA(X,n,n2,lbl,pth)

% Offline Histogram-based Tensor Analysis
%
% Inputs:
%
%   n: number of bins in the main histogram
%   n2: number of bins in distances histogram
%   lbl: lables of the dimensions. e.g. lbl{1} contains lables of items in dimension 1
%   pth: path for writing temporary and result files
% 
% Outputs:
%
%   res: inner-mode relations
%   result: cross-mode relations
%   tHist: Time (in min) required for making the main histogram 
%	tSlice: Time (in min) required for making slices histogram 
%
% IHTA requires the following MATLAB pakcages
%
%   nway331;
%      http://www.mathworks.com/matlabcentral/fileexchange/1088-the-n-way-toolbox
%   histogram_distance;
%      http://www.mathworks.com/matlabcentral/fileexchange/39275-histogram-distances
%   unique_no_sort
%      http://mathworks.com/matlabcentral/fileexchange/15209-unique-no-sort 
%   pdist3
%      http://www.mathworks.com/matlabcentral/fileexchange/29004-feature-points-in-image--keypoint-extraction/content/FPS_in_image/FPS%20in%20image/Help%20Functions/SearchingMatches/pdist2.m
%
% Note: Please check that the current directoy has premission for creating
% folder

% OHTA Example
%
%   X=rand(70,80,90);
%   [res2d res3d tHist tSlice]=OHTA(X,50,10,[],'test');
%   view the file 'test\result\OHTA-50-10.txt' for detailed results
%   results are also saved in .mat for inner and croos modes in result path
%   or simple version:
%   [inner outer]=OHTA(X,50,10);


if nargin<4 || isempty(lbl)
    order=length(size(X));
    for i=1:order
        lbl{i}=(1:size(X,i));
    end    
end    

if nargin<5
    pth='tmp'; 
end  

resultfolder=sprintf('%s\\result',pth);
if exist(resultfolder, 'dir') ~=7
    mkdir(resultfolder);
end

y = reshape(reshape(X,1,[]),[],1);
tStart=tic;
[o2 o1]=hist(y,n);
tHist = toc(tStart)/60;
disp(sprintf('Construction of main histogram : %f minutes',tHist));

tsize=size(X);
dims=length(tsize);
tStart=tic;

for dimen=1:dims
    for k=1:tsize(dimen)

        if dims==4
            if dimen==1
                m=reshape(reshape(X(k,:,:,:),1,[]),[],1);
            elseif dimen==2
                m=reshape(reshape(X(:,k,:,:),1,[]),[],1);
            elseif dimen==3
                m=reshape(reshape(X(:,:,k,:),1,[]),[],1);
            elseif dimen==4
                m=reshape(reshape(X(:,:,:,k),1,[]),[],1);
            end
        elseif dims==3
            if dimen==1
                m=reshape(reshape(X(k,:,:),1,[]),[],1);
            elseif dimen==2
                m=reshape(reshape(X(:,k,:),1,[]),[],1);
            elseif dimen==3
                m=reshape(reshape(X(:,:,k),1,[]),[],1);
            end    
        elseif dims==2
            if dimen==1
                m=reshape(reshape(X(k,:),1,[]),[],1);
            elseif dimen==2
                m=reshape(reshape(X(:,k),1,[]),[],1);
            end   
        end    
        
        b=zeros(n,1);
        for i=1:size(m,1)
            vl=abs(m(i)-o1);
            [v idx]=min(vl);
            b(idx)=b(idx)+1;
        end
       %dist{dimen}(k)=pdist3(b',o2,'cosine');        
       dist{dimen}(k)=pdist3(b',o2,'emd');
       %dist{dimen}(k)=kullback_leibler_divergence(b',o2);
       %dist{dimen}(k)=chi_square_statistics(b',o2);

    end
end    
tSlice = toc(tStart)/60;

disp(sprintf('Construction of slices histogram : %f minutes',tHist));

% ************************ make corss distances *****************************

e=0;
for dm=1:dims
    mn{dm}=min(dist{dm});
    mx{dm}=max(dist{dm});
    for j=1:size(dist{dm},2)
        nn=(dist{dm}(j)-mn{dm})/(mx{dm}-mn{dm});
        e=e+1;
        dist3d(e,1)=dm;
        dist3d(e,2)=j;
        dist3d(e,3)=nn;
    end
end

% ************************ inner-mode relations *****************************
fid=fopen(sprintf('%s\\result\\OHTA-%i-%i.txt',pth,n,n2),'w');
fprintf(fid,'------------------------------------------------\r\nTWO-WAY INTREACTIONS\r\n------------------------------------------------\r\n');
for dm=1:dims
    fprintf(fid,'\t*********************\r\n\t Mode=%i\r\n\t*********************\r\n',dm);
    mn{dm}=min(dist{dm});
    mx{dm}=max(dist{dm});
    nn=(dist{dm}-mn{dm})/(mx{dm}-mn{dm});
    d=nn';
    dsize=size(d,1);
    [nc, xout] = hist(d,n2);
    for i=1:dsize
        difv=abs(d(i)-xout);
        [v idx]=min(difv);
        d(i,2)=idx;
        d(i,3)=nc(idx);
        d(i,4)=100*d(i,3)/dsize;
        d(i,5)=i;
    end
    [vl ix]=sort(d(:,3),'descend');
    result=d(ix,:);
    
    res{dm}=result;
    % save inner relations in file
    save(sprintf('%s/result/OHTA-inner-%i-%i.mat',pth,n,n2),'res');     
    
    % human-readable results
    clu=unique_no_sort(result(:,2));
    w=0;
    for k=1:size(clu,2)
        idx=find(result(:,2)==clu(k));
        w=w+1;
        clresult=result(idx,:);
        sup=result(idx,4);
        sup=sup(1);
        fprintf(fid,'\r\n \t \t cluster=%i (support=%f)\r\n',w,sup);
        fprintf(fid,'\t \t \t');
        for i=1:size(clresult,1)
            if isa(lbl{dm},'cell')
               tit=char(lbl{dm}(clresult(i,5)));
            elseif isa(lbl{dm},'double')
               tit=num2str(lbl{dm}(clresult(i,5)));
            else
                tit=lbl{dm}(clresult(i,5));
            end
            fprintf(fid,'%s, ',tit );
        end    
    end    
    fprintf(fid,'\r\n\r\n');
end


% ************************ cross-mode relations *****************************
fprintf(fid,'------------------------------------------------\r\nMULTI-WAY INTREACTIONS\r\n------------------------------------------------\r\n');

d=dist3d(:,3);
t=size(d,1);
[nc, xout] = hist(d,n2);
for i=1:size(d,1)
	difv=abs(d(i)-xout);
    [v idx]=min(difv);
    dist3d(i,4)=idx;
    dist3d(i,5)=nc(idx);
    dist3d(i,6)=100*dist3d(i,5)/t;
end
[vl ix]=sort(dist3d(:,5),'descend');
result=dist3d(ix,:);

clu=unique_no_sort(result(:,4));
w=0;
for k=1:size(clu,2)
    idx=find(result(:,4)==clu(k));
    w=w+1;
    clresult=result(idx,:);
    sup=result(idx,6);
    sup=sup(1);
    fprintf(fid,'cluster=%i (support=%f)\r\n',w,sup);
    for i=1:size(clresult,1)
        if  isa(lbl{clresult(i,1)},'cell')
            tit=char(lbl{clresult(i,1)}(clresult(i,2)));
        elseif isa(lbl{clresult(i,1)},'double')
            tit=num2str(lbl{clresult(i,1)}(clresult(i,2)));
        else
            tit=lbl{clresult(i,1)}(clresult(i,2));
        end   
        fprintf(fid,'\t mode=%i, label=%s \r\n',clresult(i,1),tit );
    end    
end    
% ************************ end  *****************************
fclose(fid);
save(sprintf('%s/result/OHTA-cross-%i-%i.mat',pth,n,n2),'result','n','n2');        

if nargin<5
    delete('tmp/result/*.*')
    rmdir('tmp/result')
    rmdir('tmp')
end   