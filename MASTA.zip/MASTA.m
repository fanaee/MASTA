function [res result tHist tSlice]=MASTA(X,n,n2,lbl,pth)

% Multi-aspect-Streaming Tensor Analysis
% Fanaee-T, Hadi, and Gama, João. "Multi-aspect-streaming tensor analysis." Knowledge-Based Systems 89 (2015): 332-345.
%
% Inputs:
%
%   n: number of bins in the main histogram
%   n2: number of bins in distances histogram
%   lbl: labels of the dimensions. e.g. lbl{1} contains labels of items in dimension 1
%   pth: path for writing temporary and result files
% 
% Outputs:
%
%   res: inner-mode relations
%   result: cross-mode relations
%   tHist: Time (in min) required for making the main histogram incrementally
%	tSlice:Time (in min) required for making slices histogram incrementally
%
% MASTA requires the following MATLAB pakcages
%
%   nway331;
%      http://www.mathworks.com/matlabcentral/fileexchange/1088-the-n-way-toolbox
%   histogram_distance;
%      http://www.mathworks.com/matlabcentral/fileexchange/39275-histogram-distances
%   unique_no_sort
%      http://mathworks.com/matlabcentral/fileexchange/15209-unique-no-sort 
%   pdist3
%      http://www.mathworks.com/matlabcentral/fileexchange/29004-feature-points-in-image--keypoint-extraction/content/FPS_in_image/FPS%20in%20image/Help%20Functions/SearchingMatches/pdist2.m
% 
% MASTA also requires the compiled command-line executable version of gohistogram
% package: https://github.com/VividCortex/gohistogram
% which is implementation of section 2.1 of following paper :
% 
% Ben-Haim, Yael, and Elad Tom-Tov. "A streaming parallel decision tree algorithm." 
% The Journal of Machine Learning Research 11 (2010): 849-872.
% http://jmlr.org/papers/volume11/ben-haim10a/ben-haim10a.pdf
% 
% The gohistogram package is complied as win32 binary with some modifications for being
% used here. 
% hists.exe [input] [output] [n]
% where [input] is the numbers in one-column csv, [output] is bins with corresponding counts
% and [n] is maximum number of bins
% Example : hists.exe input.csv output.csv 50
%
% Note: Please ensure that the current directory has permission for creating folder
%
% MASTA Example
%
%   X=rand(70,80,90);
%   [inner outer tHist tSlice]=MASTA(X,50,10,[],'test');
%   view the file 'test\result\MASTA-50-10.txt' for detailed results
%   results are also saved in .mat for inner and croos modes in result path
%   simple usage: [inner outer]=MASTA(X,50,10);

if nargin<4 || isempty(lbl)
    order=length(size(X));
    for i=1:order
        lbl{i}=(1:size(X,i));
    end    
end    

if nargin<5
    pth='tmp'; 
end  

resultfolder=sprintf('%s\\result',pth);
if exist(resultfolder, 'dir') ~=7
    mkdir(resultfolder);
end

y = reshape(reshape(X,1,[]),[],1);
tStart=tic;
[mo1 mo2]=hists(y,n,pth,'main');
tHist = toc(tStart)/60;
disp(sprintf('Construction of main histogram : %f minutes',tHist));

tsize=size(X);
dims=size(tsize,2);
tStart=tic;
e=0;
lst=[];
cnt=[];
for dimen=1:dims
    for k=1:tsize(dimen)
    
        % for tensor with order greater than 4 modify here please
        if dims==4
            if dimen==1
                m=reshape(reshape(X(k,:,:,:),1,[]),[],1);
            elseif dimen==2
                m=reshape(reshape(X(:,k,:,:),1,[]),[],1);
            elseif dimen==3
                m=reshape(reshape(X(:,:,k,:),1,[]),[],1);
            elseif dimen==4
                m=reshape(reshape(X(:,:,:,k),1,[]),[],1);
            end
        elseif dims==3
            if dimen==1
                m=reshape(reshape(X(k,:,:),1,[]),[],1);
            elseif dimen==2
                m=reshape(reshape(X(:,k,:),1,[]),[],1);
            elseif dimen==3
                m=reshape(reshape(X(:,:,k),1,[]),[],1);
            end    
        elseif dims==2
            if dimen==1
                m=reshape(reshape(X(k,:),1,[]),[],1);
            elseif dimen==2
                m=reshape(reshape(X(:,k),1,[]),[],1);
            end   
        end    
        
        [o1 o2]=hists(m,n,pth,dimen,k);
        for f=1:size(o1,2)
            diff=abs(o1(f)-mo1);
            [vl ix]=min(diff);
            alloc(1,f)=ix;
            alloc(2,f)=o2(f);
        end    
        
        bin=zeros(1,size(mo1,2));
        uq=unique(alloc(1,:));
        for i=1:size(uq,2)
            bin(uq(i))=sum(alloc(2,find(alloc(1,:)==uq(i))));
        end
        dist{dimen}(k)=pdist3(bin,mo1,'emd');
        e=e+1;
        dist3d(e,1)=dimen;
        dist3d(e,2)=k;
        dist3d(e,3)=dist{dimen}(k);
        clear alloc o1 o2 diff vl ix bin uq;

    end
end    
tSlice = toc(tStart)/60;
disp(sprintf('Construction of slices histogram : %f minutes',tHist));

% ************************ inner-modes relations *****************************

fid=fopen(sprintf('%s\\result\\MASTA-%i-%i.txt',pth,n,n2),'w');
fprintf(fid,'------------------------------------------------\r\nTWO-WAY INTREACTIONS\r\n------------------------------------------------\r\n');
for dm=1:dims
    fprintf(fid,'\t*********************\r\n\t Mode=%i\r\n\t*********************\r\n',dm);
    d=dist{dm}';
    dsize=size(d,1);
    [xout, nc] = hists(d,n2,pth,sprintf('f-%i-%i-%i',dm,n,n2));
    dhx{dm}=xout;
    dhn{dm}=nc;
    for i=1:dsize
        difv=abs(d(i)-xout);
        [v idx]=min(difv);
        d(i,2)=idx;
        d(i,3)=nc(idx);
        d(i,4)=100*d(i,3)/dsize;
        d(i,5)=i;
    end
    [vl ix]=sort(d(:,3),'descend');
    result=d(ix,:);
    
    res{dm}=result;
   
    % save inner-mode relation results in file *************************
    save(sprintf('%s\\result\\MASTA-inner-%i-%i.mat',pth,n,n2),'res');            
    
    
    % Creating a human-readable version of results
    clu=unique_no_sort(result(:,2));
    w=0;
    for k=1:size(clu,2)
        idx=find(result(:,2)==clu(k));
        w=w+1;
        clresult=result(idx,:);
        sup=result(idx,4);
        sup=sup(1);
        fprintf(fid,'\r\n \t \t cluster=%i (support=%f)\r\n',w,sup);
        fprintf(fid,'\t \t \t');
        for i=1:size(clresult,1)
            if isa(lbl{dm},'cell')
               tit=char(lbl{dm}(clresult(i,5)));
            elseif isa(lbl{dm},'double')
               tit=num2str(lbl{dm}(clresult(i,5)));
            else
                tit=lbl{dm}(clresult(i,5));
            end  
            fprintf(fid,'%s, ',tit );
        end    
    end    
    fprintf(fid,'\r\n\r\n');
end
% ************************ cross-mode relations *****************************
fprintf(fid,'------------------------------------------------\r\nMULTI-WAY INTREACTIONS\r\n------------------------------------------------\r\n');


d=dist3d(:,3);
%[nc, xout] = hist(d,n2);
[xout, nc] = hists(d,n2,pth,sprintf('all-%i-%i',n,n2));

t=size(d,1);
for i=1:size(d,1)
	difv=abs(d(i)-xout);
    [v idx]=min(difv);
    dist3d(i,4)=idx;
    dist3d(i,5)=nc(idx);
    dist3d(i,6)=100*dist3d(i,5)/t;
end

[vl ix]=sort(dist3d(:,5),'descend');
result=dist3d(ix,:);

clu=unique_no_sort(result(:,4));
w=0;
for k=1:size(clu,2)
    idx=find(result(:,4)==clu(k));
    w=w+1;
    clresult=result(idx,:);
    sup=result(idx,6);
    sup=sup(1);
    fprintf(fid,'cluster=%i (support=%f)\r\n',w,sup);
    for i=1:size(clresult,1)
        if  isa(lbl{clresult(i,1)},'cell')
            tit=char(lbl{clresult(i,1)}(clresult(i,2)));
        elseif isa(lbl{clresult(i,1)},'double')
            tit=num2str(lbl{clresult(i,1)}(clresult(i,2)));
        else
            tit=lbl{clresult(i,1)}(clresult(i,2));
        end   
        fprintf(fid,'\t mode=%i, label=%s \r\n',clresult(i,1),tit );
    end    
end    
% ************************ end 3d *****************************

fclose(fid);
save(sprintf('%s\\result\\MASTA-cross-%i-%i.mat',pth,n,n2),'result','n','n2');        


if nargin<5
    delete('tmp/input/*.*')
    rmdir('tmp/input')
    delete('tmp/output/*.*')
    rmdir('tmp/output')
    delete('tmp/result/*.*')
    rmdir('tmp/result')
    rmdir('tmp')
end   
 